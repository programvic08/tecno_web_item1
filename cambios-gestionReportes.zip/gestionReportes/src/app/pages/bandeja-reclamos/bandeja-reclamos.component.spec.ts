import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { StatusBadgeComponent } from '../../shared/components/status-badge/status-badge.component';
import { AgenteComboboxComponent } from '../../shared/components/agente-combobox/agente-combobox.component';
import { ReclamoService } from '../../core/services/reclamo.service';
import { AuthService } from '../../core/services/auth.service';
import { USUARIO_ADMIN_PRUEBA } from '../../testing/usuarios-prueba';

import { BandejaReclamosComponent } from './bandeja-reclamos.component';

describe('BandejaReclamosComponent', () => {
  let component: BandejaReclamosComponent;
  let fixture: ComponentFixture<BandejaReclamosComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BandejaReclamosComponent, StatusBadgeComponent, AgenteComboboxComponent ],
      imports: [ FormsModule, RouterTestingModule ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BandejaReclamosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('ordena los reclamos por puntaje de prioridad, de mayor a menor, al entrar', () => {
    spyOn(TestBed.inject(AuthService), 'obtenerUsuarioActual').and.returnValue(USUARIO_ADMIN_PRUEBA);
    TestBed.inject(ReclamoService).cargarReclamosDemo();
    component.reclamos = [];
    component.ngOnInit();
    const abiertos = component.reclamosFiltrados.filter(r => r.estado !== 'Cerrado');
    const puntajes = abiertos.map(r => r.puntaje?.total ?? 0);
    expect(puntajes.length).toBeGreaterThan(1);
    expect(puntajes).toEqual([...puntajes].sort((a, b) => b - a));
  });


  describe('filtro de asignación y carga de los agentes', () => {
    beforeEach(() => {
      spyOn(TestBed.inject(AuthService), 'obtenerUsuarioActual').and.returnValue(USUARIO_ADMIN_PRUEBA);
      TestBed.inject(ReclamoService).cargarReclamosDemo();
      component.esAdmin = true;
      component.usuarioId = USUARIO_ADMIN_PRUEBA.id;
      component.ngOnInit();
    });

    it('"Sin asignar" deja solo los reclamos que no tienen agente', () => {
      component.filtroAsignacion = 'Sin asignar';
      const esperados = component.reclamos.filter(r => !r.agenteId).length;
      expect(esperados).toBeGreaterThan(0);
      expect(component.reclamosFiltrados.length).toBe(esperados);
      expect(component.reclamosFiltrados.every(r => !r.agenteId)).toBeTrue();
    });

    it('"Asignados a mí" deja solo los reclamos del administrador con sesión', () => {
      component.filtroAsignacion = 'Asignados a mí';
      const lista = component.reclamosFiltrados;
      expect(lista.length).toBeGreaterThan(0);
      expect(lista.every(r => r.agenteId === USUARIO_ADMIN_PRUEBA.id)).toBeTrue();
    });

    it('"Todos" no filtra, y el agente nunca recibe este filtro', () => {
      component.filtroAsignacion = 'Todos';
      const total = component.reclamosFiltrados.length;
      expect(total).toBe(component.reclamos.length);

      component.esAdmin = false;
      component.filtroAsignacion = 'Sin asignar';
      expect(component.reclamosFiltrados.length).toBe(total);
    });

    it('cuenta como activos solo los reclamos que no están cerrados, resueltos ni rechazados', () => {
      const gomez = component.agentesConCarga.find(a => a.nombre === 'Agente Gómez')!;
      // Demo: uno en revisión y uno en proceso activos, y uno rechazado que no cuenta
      expect(gomez.reportesActivos).toBe(2);
      const asignadosAGomez = component.reclamos.filter(r => r.agenteId === gomez.id).length;
      expect(asignadosAGomez).toBeGreaterThan(gomez.reportesActivos!);
    });
  });

});
